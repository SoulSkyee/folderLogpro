NamaPengguna = input("Isikan nama Anda:")
Label = "Selamat datang, " + NamaPengguna
print(Label)
