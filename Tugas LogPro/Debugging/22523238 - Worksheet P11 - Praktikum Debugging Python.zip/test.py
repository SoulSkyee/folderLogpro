nums = [1,2,3,4]
total = 0
for n in nums:
    total = total + n  
print(total)    
