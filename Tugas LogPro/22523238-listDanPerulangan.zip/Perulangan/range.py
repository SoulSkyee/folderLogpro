
print(range(10))            
print(list(range(10)))      
print(list(range(2, 8)))    
print(list(range(0, 25, 4)))
