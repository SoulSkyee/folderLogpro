list1 = ['physics', 'chemistry', 1997, 2000]
list2 = [1,2,3,4,5,6,7]

print("list1[0]: ", list1[0])
print("list2[1:5 ]: " , list2[1:5])
