mylist = []
print(type(mylist))
print(mylist)

for x in range(6):
    mylist.append(x)

print(mylist)