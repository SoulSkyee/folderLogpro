# NOTE - use of else statement with while looop

counter = 0

while counter < 3:
    print("Inside Loop")
    counter = counter + 1
else:
    print("Inside else")